﻿using System.Reflection;

[assembly: AssemblyTitle("RimUniverse.CoreModule")]
[assembly: AssemblyProduct("RimUniverse.CoreModule")]
[assembly: AssemblyCopyright("Copyright © 2020")]
[assembly: AssemblyTrademark("Balthoraz")]
[assembly: AssemblyVersion("1.01.0057")]