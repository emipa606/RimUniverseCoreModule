﻿using JetBrains.Annotations;
using RimUniverse.CoreModule;
using RimWorld;
using System;
using System.Linq;
using Verse;

namespace RimUniverse.Submods.ShowModDesignators
{
    [StaticConstructorOnStartup]
    [UsedImplicitly]
    public class ShowModDesignators
    {
        static ShowModDesignators()
        {
            if (Controller.Settings.showModDesignators.Equals(false))
                return;

            foreach (ModContentPack modContentPack in LoadedModManager.RunningMods.Where(predicate: modContentPack => !modContentPack.IsCoreMod))
                foreach (Def def in modContentPack.AllDefs)
                {
                    try
                    {
                        string nameAdd = $"\n({modContentPack.Name})".Replace(oldChar: '[', newChar: '(').Replace(oldChar: ']', newChar: ')');
                        if (!def.description.NullOrEmpty())
                            def.description += nameAdd;
                        switch (def)
                        {
                            case TraitDef traitDef:
                                foreach (TraitDegreeData traitDegreeData in traitDef.degreeDatas)
                                    traitDegreeData.description += nameAdd;
                                break;
                            case ThingDef thingDef:
                                if (thingDef.race != null)
                                {
                                    if (thingDef.race.meatDef != null)
                                        thingDef.race.meatDef.description += nameAdd;
                                    if (thingDef.race.corpseDef != null)
                                        thingDef.race.corpseDef.description += nameAdd;
                                    if (thingDef.race.leatherDef != null)
                                        thingDef.race.leatherDef.description += nameAdd;
                                }
                                break;
                        }
                        if (BackstoryDatabase.allBackstories.TryGetValue(key: def.defName, value: out Backstory backStory))
                            backStory.baseDesc += nameAdd;
                    }
                    catch (Exception)
                    {
                        Log.Error(text: $"RimUniverse - ShowModDesignator: {def.defName} of {def.GetType()} is evil");
                    }
                }
        }
    }
}